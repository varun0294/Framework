//
//  AlmoWater.h
//  AlmoWater
//
//  Created by Varun Wadhwa on 15/07/17.
//  Copyright © 2017 Varun Wadhwa. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AlmoWater.
FOUNDATION_EXPORT double AlmoWaterVersionNumber;

//! Project version string for AlmoWater.
FOUNDATION_EXPORT const unsigned char AlmoWaterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AlmoWater/PublicHeader.h>


